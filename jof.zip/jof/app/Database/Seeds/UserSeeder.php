<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use CodeIgniter\I18n\Time;
use App\Models\Users;
class UserSeeder extends Seeder
{
    public function run()
    {
        $user_model = new Users;
        $user_model->save([
            'user_name'=>'Administrator',
            'user_phone' => '9448379279',
            'user_email' => 'admin@mail.com',
            'password' => password_hash('admin123', PASSWORD_DEFAULT),
        ]);
    }
}
