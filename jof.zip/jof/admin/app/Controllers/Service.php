<?php

namespace App\Controllers;

defined('BASEPATH') or exit('No direct script access allowed');
use App\Controllers\BaseController;
use App\Models\Services as Services_Model;

class Service extends BaseController
{

    public function __construct()
    {
        parent::__construct();
        $this->services_model = new Services_Model();
        $request = \Config\Services::request();
        helper(['form', 'url', 'string']);
        $session = session();
        $pot = json_decode(json_encode($session->get("userdata")), true);
        if (empty($pot)) {
            return redirect()->to("/");
        } else {
            $role_id = $pot["role_id"];
        }
        $menutext = $this->request->uri->getSegment(2);
        if (isset($_SESSION['sidebar_menuitems'])) {
            foreach ($_SESSION['sidebar_menuitems'] as $main_menus):
                if (strtolower($main_menus->menuitem_link) == strtolower($menutext)) {
                    $permissions = $this->admin_roles_accesses_model->get_permisions($role_id, $main_menus->menuitem_id);
                    $this->permission = array($permissions->add_permission, $permissions->edit_permission, $permissions->delete_permission);
                } else {
                    if (!empty($main_menus->submenus)):
                        foreach ($main_menus->submenus as $submenus):
                            if (strtolower($submenus->menuitem_link) == strtolower($menutext)) {
                                $permissions = $this->admin_roles_accesses_model->get_permisions($role_id, $submenus->menuitem_id);
                                $this->permission = array($permissions->add_permission, $permissions->edit_permission, $permissions->delete_permission);
                            }
                        endforeach;
                    endif;
                }
            endforeach;
        }
    }

    public function index()
    {
        $this->loadUser();
        $session = session();
        $pot = json_decode(json_encode($session->get("userdata")), true);
        if (empty($pot)) {
            return redirect()->to("/");
        }
        $data['session'] = $session;
        $data['title'] = 'Service Details';
        $data['services'] = $this
        ->services_model->
        orderBy('service_id', 'DESC')->findAll();
        $data['page_heading'] = 'Add New Service';
        $data['request'] = $this->request;
        $data['menuslinks'] = $this
            ->request
            ->uri
            ->getSegment(1);
        if ($this->permission[0] > 0) {
            $data["link"] = "addnewservicelist";
        } else {
            $data["link"] = "#";
        }
        if ($this->permission[1] > 0) {
            $data["edit_service"] = "edit_service";
        } else {
            $data["edit_service"] = "#";
        }
        if ($this->permission[2] > 0) {
            $data["delete_service"] = "delete_service";
        } else {
            $data["delete_service"] = "#";
        }
        $data["view"] = "services/servicelist";
        return view('templates/default', $data);
    }

// add new services

    public function addNewServices()
    {
        $this->loadUser();
        $session = session();
        $pot = json_decode(json_encode($session->get("userdata")), true);
        if (empty($pot)) {
            return redirect()->to("/");
        }

        $data['session'] = $session;
        $data['title'] = 'Add Service Details';
        $data['pade_title2'] = 'Select Company Name';
        $data['pade_title1'] = 'Add Services Description';
        $data['pade_title2'] = 'Add Conditions';
        $data['pade_title6'] = 'Add Services';
        $data['pade_title3'] = 'Add Service  Name';
        $data['pade_title4'] = 'Select Service Category';
        $data['pade_title5'] = 'Add Service Cost';
        $data['page_heading'] = 'Add Service Thumbnail';
        $data['request'] = $this->request;
        $data['menuslinks'] = $this
            ->request
            ->uri
            ->getSegment(1);
        $data["view"] = "services/addnewservices";
        return view('templates/default', $data);
    }

// save sewrvice

    public function savenewserviceinfo()
    {
        $this->loadUser();
        $session = session();
        $pot = json_decode(json_encode($session->get("userdata")), true);
        if (empty($pot)) {
            return redirect()->to("/");
        } else {
            $user_id = $pot['user_id'];
            $role_id = $pot['role_id'];
        }
        // helper(['form', 'url']);
        if ($this
            ->request
            ->getMethod() == 'post') {
            extract($this
                    ->request
                    ->getPost());
        }
        $input = $this->validate(['service_name' => 'required|min_length[3]', 'editor1' => 'required|min_length[10]', 'serviceduration' => 'required', 'status_ind' => 'required']);
        if (!empty($input)) {
            $validated = $this->validate(['file' => ['uploaded[file]', 'mime_in[file,image/jpg,image/jpeg,image/gif,image/png]', 'max_size[file,4096]']]);
            if (!empty($service_id_hidd)) {
                if ($validated) {
                    $slider_picture = $this->services_model->select(['Service_thumbnail'])->where('service_id', $service_id_hidd)->first();
                    $file_delete = dirname(__FILE__, 3);
            
                    foreach ($slider_picture as $slider) {
                        unlink($file_delete . "/uploads/" . $slider);
                    }
                    $avatar = $this
                        ->request
                        ->getFile('file');
                    if ($avatar->isValid() && !$avatar->hasMoved()) {
                        $name = $avatar->getName();
                        $ext = $avatar->getClientExtension();
                        $avatar->move('admin/uploads/', $name);
                        $filepath = base_url() . "/uploads/" . $name;
                        session()->setFlashdata('filepath', $filepath);
                        session()->setFlashdata('extension', $ext);
                    }
           
                    $data = ['Service_thumbnail' => $avatar->getClientName(), 'servicename' => $service_name, 'servicesdescription' => $editor1, 'servicescondition' => $editor2, 'services' => $editor3, 'duration' => $serviceduration, 'servicecost' => $service_cost,  'status_ind' => $status_ind, 'created_at' => date('Y-m-d')];
                    $update = $this
                        ->services_model
                        ->where('service_id', $service_id_hidd)->set($data)->update();
                        if ($update) {
                            $session->setFlashdata('success', 'Service Data has been updated');
                    } else {
                        $session->setFlashdata('error', 'Service Failed to update');
                    }
                        return redirect()->to('services');
                } else {
                    $data = ['servicename' => $service_name, 'servicesdescription' => $editor1, 'servicescondition' => $editor2, 'services' => $editor3, 'duration' => $serviceduration, 'servicecost' => $service_cost, 'status_ind' => $status_ind, 'created_at' => date('Y-m-d')];
            
                    $update = $this
                        ->services_model
                        ->where('service_id', $service_id_hidd)->set($data)->update();
                    if ($update) {
                            $session->setFlashdata('success', 'Service Data has been updated');
                    } else {
                        $session->setFlashdata('error', 'Service Failed to update');
                    }
                    return redirect()->to('services');
                }
            } else {
                if ($validated) {
                    $avatar = $this
                        ->request
                        ->getFile('file');
                    //$avatar->move(WRITEPATH . 'uploads');
                    if ($avatar->isValid() && !$avatar->hasMoved()) {
                        $name = $avatar->getName();
                        $ext = $avatar->getClientExtension();
                        $avatar->move('admin/uploads/', $name);
                        //$avatar->move(WRITEPATH . 'uploads', $name);
                        $filepath = base_url() . "/uploads/" . $name;
                        // File path to display preview
                        // $filepath = WRITEPATH . "uploads";
                        session()->setFlashdata('filepath', $filepath);
                        session()->setFlashdata('extension', $ext);
                    }
                    $data = ['Service_thumbnail' => $avatar->getClientName(), 'servicename' => $service_name, 'servicesdescription' => $editor1, 'servicescondition' => $editor2, 'services' => $editor3, 'duration' => $serviceduration, 'servicecost' => $service_cost, 'status_ind' => $status_ind, 'created_at' => date('Y-m-d')];
                    $save = $this
                        ->services_model
                        ->save($data);
                    $session->setFlashdata('success', 'Service Saved Successsfully');

                } else {
                    $session->setFlashdata('error', 'Please select a valid file');
                }
            }
        } else {
            $session->setFlashdata('error', 'Fill All Fields');
        }
        return redirect()->to('services');
    }

// edit service

    public function edit_service($id = '')
    {
        if ($id == null) {
            return redirect()->to("Admindashboard");
        }
        $this->loadUser();
        $session = session();
        $pot = json_decode(json_encode($session->get("userdata")), true);
        if (empty($pot)) {
            return redirect()->to("/");
        }
        $data['session'] = $session;
        $data['title'] = 'Edit Services Details';
        $data['pade_title2'] = 'Edit Conditions';
        $data['pade_title6'] = 'Edit Services';
        $data['pade_title1'] = 'Edit Sevice Description';
        $data['pade_title3'] = 'Edit Service  Name';
        $data['pade_title4'] = 'Select Service Category';
        $data['pade_title5'] = 'Edit Service Cost';
        $data['query'] = $this
            ->services_model
            ->where('service_id',$id)->first();
        $data['page_heading'] = 'Edit Sevice Thumbnail';
        $data['request'] = $this->request;
        $data['menuslinks'] = $this
            ->request
            ->uri
            ->getSegment(1);
        $data["view"] = "services/addnewservices";
        return view('templates/default', $data);
    }

// service delete

    public function service_delete($id = '')
    {
        if ($id == null) {
            return redirect()->to("Admindashboard");
        }
        $this->session = session();
        $session = session();
        $pot = json_decode(json_encode($session->get('userdata')), true);
        if (empty($pot)) {
            return redirect()->to("/");
        }
        $slider_picture = $this->services_model->select(['Service_thumbnail'])->where('service_id', $id)->first();
        $file_delete = dirname(__FILE__, 3);

        foreach ($slider_picture as $slider) {
            unlink($file_delete . "/uploads/" . $slider);
        }
        $delete = $this
            ->services_model
            ->where('service_id', $id)->delete();
        if ($delete) {
            $session->setFlashdata(
                "success",
                "Slider has been deleted successfully."
            );
        } else {
            $session->setFlashdata('error', 'Failed to Delete');
        }
        $data['request'] = $this->request;
        $data['menuslinks'] = $this
            ->request
            ->uri
            ->getSegment(1);

        return redirect()->to("services");
    }

}
