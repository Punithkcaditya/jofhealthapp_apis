<div class="header header-fixed header-auto-show header-logo-app">
        <a href="<?php echo site_url("/"); ?>"
            class="header-title"><?php echo !empty(get_cookie("location")) ? get_cookie("location") : "Location" ?></a>
        <a href="#" data-back-button class="header-icon header-icon-1"><i class="fas fa-arrow-left"></i></a>
        <a href="#" data-toggle-theme class="header-icon header-icon-2 show-on-theme-dark"><i
                class="fas fa-sun"></i></a>

    </div>
    <div class="menu-hider"></div>