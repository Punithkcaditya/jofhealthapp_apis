<?= $this->extend('layouts/loginheader') ?>
<?= $this->section('content') ?>
<?= $this->include($view) ?>
<?= $this->endSection() ?>