<!-- Page content -->
<div class="container-fluid pt-8">

    <div class="row">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-header">
                    <h2 class="mb-0"><?= $title ?></h2>

                </div>
                <div class="card-body">
                    <div class="table-responsives">
                        <form action="<?= base_url(
                                                "savenewserviceinfo"
                                            ) ?>" method="POST" enctype="multipart/form-data">
                            <div class="row">

                                <div class="col-md-12">
                                    <div class="card shadow">
                                        <div class="card-header">
                                            <!-- <h2 class="mb-0"></h2> -->
                                        </div>

                                        <div class="card-body">
                                            <?= $this->include('message/message') ?>

                                            <div class="row">
                                                <div class="col-md-12">


                                                    <div class="form-group">
                                                        <input type="hidden" name="service_id_hidd" id="service_id_hidd"
                                                            value="<?php echo !empty( $query['service_id'])? $query['service_id']: ""; ?>" />
                                                        <label class="form-label"><?= $pade_title3 ?></label>
                                                        <input type="text" class="form-control" name="service_name"
                                                            id="service_name" placeholder="Enter Service Name" value="<?= !empty(
                                                                                    $query['servicename']
                                                                                )
                                                                                    ? $query['servicename'] : "" ?>" required>
                                                    </div>




                                                    <div class="form-group">
                                                        <label class="form-label"><?= "Enter Duration" ?></label>
                                                        <input type="number" class="form-control" name="serviceduration"
                                                            id="serviceduration" placeholder="Enter Duration" value="<?= !empty(
                                                                                    $query['duration']
                                                                                )
                                                                                    ? $query['duration']
                                                                                    : "" ?>" required>
                                                    </div>

                                               


                                                    <div class="form-group">

                                                        <label class="form-label"><?= $pade_title5 ?></label>
                                                        <input type="number" class="form-control" name="service_cost"
                                                            id="service_cost" placeholder="Enter Service Cost" value="<?= !empty(
                                                                                    $query['servicecost']
                                                                                )
                                                                                    ? $query['servicecost']
                                                                                    : "" ?>" required>
                                                    </div>


                                                    <div class="form-group">
                                                        <label class="form-label">Choose Service
                                                            Status</label>
                                                        <select name="status_ind" id="status_ind" class="form-control"
                                                            required>
                                                            <option value="">-- Service Status --
                                                            </option>

                                                            <option value="1" <?php echo !empty(
                                                                                        $query['status_ind']
                                                                                    ) &&
                                                                                    $query['status_ind'] ==
                                                                                        1
                                                                                        ? "selected"
                                                                                        : ""; ?>>
                                                                Active</option>
                                                            <option value="0" <?php echo !empty(
                                                                                      $query['status_ind']
                                                                                    ) &&
                                                                                    $query['status_ind'] ==
                                                                                        0
                                                                                        ? "selected"
                                                                                        : ""; ?>>
                                                                Inactive</option>
                                                        </select>
                                                    </div>


                                                    <div class="form-group">
                                                        <div class="preview">
                                                            <img id="file-ip-1-preview">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">

                                                        <?php if (
                                                                                !empty(
                                                                                    $query['Service_thumbnail']
                                                                                )
                                                                            ) { ?>

                                                        <img style="width: 139px;" id="blah" src="<?= base_url(
                                                                                    "uploads/" .
                                                                                    $query['Service_thumbnail']
                                                                                ) ?>" />

                                                        <?php } else { ?>
                                                        <div id="blah"></div>
                                                        <?php } ?>

                                                    </div>


                                                    <div class="form-group">
                                                        <label for="formGroupExampleInput"><?= $page_heading ?></label>
                                                        <input type="file" name="file" class="form-control" id="file"
                                                            onchange="showPreview(event);" accept=".png, .jpg, .jpeg"
                                                            <?php echo !empty( $query['service_id'])? '': "required"; ?> />
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="formGroupExampleInput"><?= $pade_title1 ?></label>
                                                        <textarea id="editor1" name="editor1" required><?php echo htmlspecialchars(
                                                                                    !empty(
                                                                                        $query['servicesdescription']
                                                                                    )
                                                                                        ?  $query['servicesdescription']
                                                                                        : ""
                                                                                ); ?></textarea>
                                                    </div>

                                                               <div class="form-group">
                                                        <label for="formGroupExampleInput"><?= $pade_title2 ?></label>
                                                        <textarea id="editor2" name="editor2" required><?php echo htmlspecialchars(
                                                                                    !empty(
                                                                                        $query['servicescondition']
                                                                                    )
                                                                                        ?  $query['servicescondition']
                                                                                        : ""
                                                                                ); ?></textarea>
                                                    </div>

                                                               <div class="form-group">
                                                        <label for="formGroupExampleInput"><?= $pade_title6 ?></label>
                                                        <textarea id="editor3" name="editor3" required><?php echo htmlspecialchars(
                                                                                    !empty(
                                                                                        $query['services']
                                                                                    )
                                                                                        ?  $query['services']
                                                                                        : ""
                                                                                ); ?></textarea>
                                                    </div>

                                                    <div class="col-md-12" style="text-align: center;">
                                                        <div class="d-grid gap-1">
                                                            <button
                                                                class="btn rounded-0 btn-primary bg-gradient">Save</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>

        </div>
    </div>

</div>

<script>
CKEDITOR.replace('editor1');
CKEDITOR.replace('editor2');
CKEDITOR.replace('editor3');

function displayDivDemo(id, elementValue) {

    document.getElementById(id).style.display = elementValue.value == 1 ? 'block' : 'none';
}
</script>