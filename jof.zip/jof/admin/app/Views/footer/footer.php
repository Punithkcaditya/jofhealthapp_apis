<footer class="footer">
							<div class="row align-items-center justify-content-xl-between">
								<div class="col-xl-12">
									<div class="copyright text-center text-xl-left text-muted">
										<p class="text-sm font-weight-500">Copyright 2022 © Superior Codelabs All Rights Reserved.Dashboard Admindashboard Template</p>
									</div>
								</div>
					
							</div>
						</footer>