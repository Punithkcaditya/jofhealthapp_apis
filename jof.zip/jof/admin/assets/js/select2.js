$(function(e) {
	'use strict';
	$('.select2').select2()
	$("#e2").select2({
		placeholder: "Select a State",
		allowClear: true
	});
});